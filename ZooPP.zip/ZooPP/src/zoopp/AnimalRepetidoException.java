
package zoopp;


public class AnimalRepetidoException extends RuntimeException {

    private final static String MESSAGE = "El animal ya está registrado en el sistema";
    
    public AnimalRepetidoException() {
        super(MESSAGE);
    }


}


