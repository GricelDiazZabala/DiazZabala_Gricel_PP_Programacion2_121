
package zoopp;

import java.util.ArrayList;



public class Zoo {
    
    String nombre;
    Animal animal;
    private ArrayList<Animal> animales;

    public Zoo(String nombre) {
        this.nombre = nombre;
    }
    
    public void agregarAnimal(Animal animal) throws AnimalRepetidoException {
        if (animales.contains(animal)) {
            throw new AnimalRepetidoException();
        }
        animales.add(animal);
        System.out.println("Animal agregado: " + animal);
    }

    
    public void mostrarAnimales() {
        if (animales.isEmpty()) {
            System.out.println("No hay animales en el zoológico.");
        } else {
            System.out.println("Animales en el zoológico:");
            for (Animal a : animales) {
                System.out.println(a);
            }
        }
    }
    
        public void vacunarAnimales() {
        for (Animal a : animales) {
            try {
                a.vacunar();
            } catch (UnsupportedOperationException e) {
                System.out.println("El animal " + a.getNombre() + " no puede ser vacunado.");
            }
        }
    }
    
}

