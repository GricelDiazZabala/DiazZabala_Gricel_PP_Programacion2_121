
package zoopp;

public class Mamifero extends Animal{
    
    boolean vacunable;

    public Mamifero(boolean vacunable, Tipo tipo, String nombre, int edad, double peso, Dieta dieta) {
        super(tipo, nombre, edad, peso, dieta);
        this.vacunable = vacunable;
    }



    //acá van los overrides porque la clase animal es abstracta
    @Override
    public String toString() {
        return "Mamifero [peso=" + peso + ", dieta=" + dieta + "]";
    }

    @Override
    public void vacunar() {
        System.out.println("El mamífero " + nombre + " ha sido vacunado.");
    }
    
    
}
