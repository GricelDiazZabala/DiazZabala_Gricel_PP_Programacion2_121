
package zoopp;


public class TestZooPP {

    public static void main(String[] args) {
        
        Zoo zoo = new Zoo("Zoo de la ciudad");

        Animal mamifero = new Mamifero("Diego", 6, 66.8, herbivoro);
        Animal ave = new Ave(2.5, true, "Héctor", 2, 1.3, carnivoro);
        Animal reptil = new Reptil("Escamas blandas", 6, "Ectotérmico", "Bella", 2.5, carnivoro);

        try {
            zoo.agregarAnimal(mamifero);
            zoo.agregarAnimal(ave);
            zoo.agregarAnimal(reptil);
            zoo.agregarAnimal(mamifero);  // acá manda excepcion
        } catch (AnimalRepetidoException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\nAnimales en el zoológico:");
        zoo.mostrarAnimales();

        System.out.println("\nVacunando animales:");
        zoo.vacunarAnimales();
    }

}
