
package zoopp;

public class Reptil extends Animal {
    
    String tipoEscama;
    String regulacionTemperatura;

    public Reptil(String tipoEscama, String regulacionTemperatura, Tipo tipo, String nombre, int edad, double peso, Dieta dieta) {
        super(tipo, nombre, edad, peso, dieta);
        this.tipoEscama = tipoEscama;
        this.regulacionTemperatura = regulacionTemperatura;
    }



    //acá van los overrides porque la clase animal es abstracta
    
    @Override
    public String toString() {
        return "Reptil [tipoEscama=" + tipoEscama + ", regulacionTemperatura=" + regulacionTemperatura + "]";
    }


    @Override
    public void vacunar() {
        throw new UnsupportedOperationException("Este animal no puede ser vacunado.");
    }

    
    
}
