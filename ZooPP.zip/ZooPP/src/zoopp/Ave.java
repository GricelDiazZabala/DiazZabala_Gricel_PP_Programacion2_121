
package zoopp;


public class Ave extends Animal {
    
    double envergaduraAlas;
    boolean vacunable;

    public Ave(double envergaduraAlas, boolean vacunable, Tipo tipo, String nombre, int edad, double peso, Dieta dieta) {
        super(tipo, nombre, edad, peso, dieta);
        this.envergaduraAlas = envergaduraAlas;
        this.vacunable = vacunable;
    }


    //acá van los overrides porque la clase animal es abstracta
    
    @Override
    public String toString() {
        return "Ave [envergaduraAlas=" + envergaduraAlas + "]";
    }

    @Override
    public void vacunar() {
        System.out.println("El ave " + nombre + " ha sido vacunado.");
    }
    
    
}
