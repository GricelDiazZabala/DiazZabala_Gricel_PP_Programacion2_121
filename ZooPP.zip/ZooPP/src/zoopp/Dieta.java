
package zoopp;

public enum Dieta {
    herbivoro,
    carnivoro,
    omnivoro
    
}
