
package zoopp;


public enum Tipo {
    
    mamifero,
    ave,
    reptil
    
}
